$(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        loop:true,
        margin:10,
        items:1,
        rtl:true,
        nav:true,
        navText :[" السابق" , " التالى "],
    });
  });